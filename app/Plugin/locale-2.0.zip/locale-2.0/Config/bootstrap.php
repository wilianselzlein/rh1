<?php
/* Configuração default para o Behavior Locale */
Configure::write('Language.default', 'pt-br');

/* Definição de timezone para usar a classe DateTime */
date_default_timezone_set('America/Sao_Paulo');

/* Definição de locale para formatar saída de Data, Hora, moedas e etc */
setlocale(LC_ALL, 'pt_BR.utf-8', 'pt_BR', 'pt-br', 'pt_BR.iso-8859-1');
